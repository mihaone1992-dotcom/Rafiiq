/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0A1830',
        surface: '#122642',
        surfaceAlt: '#17304F',
        line: '#223A5C',
        accent: '#33D69F',
        accentDim: '#1E4A3D',
        accentInk: '#04140F',
        ink: '#F4F8FB',
        inkMuted: '#8FA6C4',
        inkFaint: '#5E7595',
      },
      fontFamily: {
        cairo: ['Cairo', 'sans-serif'],
        tajawal: ['Tajawal', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
