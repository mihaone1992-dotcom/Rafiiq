import { useState } from 'react';

const PRAYERS = [
  { name: 'العصر', time: '5:42 مساءً' },
  { name: 'المغرب', time: '7:35 مساءً' },
  { name: 'العشاء', time: '9:00 مساءً' },
];

export default function Religion() {
  const [count, setCount] = useState(0);

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-sm text-inkFaint">مواقيت الصلاة</h2>
      <div className="bg-surface border border-line rounded-2xl overflow-hidden">
        {PRAYERS.map((p) => (
          <div key={p.name} className="flex justify-between px-4 py-3 border-b border-line last:border-b-0 text-sm">
            <span>{p.name}</span>
            <span className="text-inkFaint text-xs">{p.time}</span>
          </div>
        ))}
      </div>
      <div className="bg-surface border border-line rounded-2xl p-6 flex flex-col items-center gap-1">
        <div className="font-cairo font-extrabold text-4xl text-accent">{count}</div>
        <div className="text-xs text-inkFaint">تسبيح اليوم</div>
        <button
          onClick={() => setCount((c) => c + 1)}
          className="mt-3 bg-accent text-accentInk font-bold rounded-full px-8 py-3 text-sm"
        >
          سبّح
        </button>
      </div>
    </div>
  );
}
