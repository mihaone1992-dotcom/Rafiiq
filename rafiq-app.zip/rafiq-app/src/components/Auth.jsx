import { useState } from 'react';
import { supabase } from '../supabaseClient';

export default function Auth() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSignIn(e) {
    e.preventDefault();
    setLoading(true);
    setMessage('جارٍ الدخول...');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setMessage(error.message === 'Invalid login credentials' ? 'البريد أو كلمة السر غير صحيحة.' : error.message);
    }
  }

  async function handleSignUp() {
    setLoading(true);
    setMessage('جارٍ إنشاء الحساب...');
    const { error } = await supabase.auth.signUp({ email, password });
    setLoading(false);
    if (error) {
      setMessage(error.message);
    } else {
      setMessage('تم إنشاء الحساب. تحقق من بريدك الإلكتروني لتأكيده، ثم سجّل الدخول.');
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="flex flex-col items-center gap-3">
          <svg viewBox="0 0 76 76" className="w-14 h-14">
            <circle cx="30" cy="38" r="21" fill="none" stroke="#33D69F" strokeWidth="3" />
            <circle cx="48" cy="38" r="13" fill="#33D69F" />
          </svg>
          <h1 className="font-cairo font-extrabold text-xl">تسجيل الدخول إلى رفيق</h1>
        </div>
        <form onSubmit={handleSignIn} className="flex flex-col gap-3">
          <input
            type="email"
            required
            placeholder="البريد الإلكتروني"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="bg-surface border border-line rounded-full px-4 py-3 text-sm outline-none focus:border-accent"
          />
          <input
            type="password"
            required
            placeholder="كلمة السر"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="bg-surface border border-line rounded-full px-4 py-3 text-sm outline-none focus:border-accent"
          />
          <div className="flex gap-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-accent text-accentInk font-bold rounded-full py-3 text-sm disabled:opacity-50"
            >
              دخول
            </button>
            <button
              type="button"
              onClick={handleSignUp}
              disabled={loading}
              className="flex-1 bg-surfaceAlt text-ink font-bold rounded-full py-3 text-sm disabled:opacity-50"
            >
              إنشاء حساب
            </button>
          </div>
        </form>
        {message && <p className="text-xs text-inkFaint text-center">{message}</p>}
      </div>
    </div>
  );
}
