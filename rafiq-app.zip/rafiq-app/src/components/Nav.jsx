const ITEMS = [
  { key: 'home', label: 'الرئيسية' },
  { key: 'tasks', label: 'المهام' },
  { key: 'chat', label: 'دردشة' },
  { key: 'health', label: 'الصحة' },
  { key: 'religion', label: 'دين' },
  { key: 'education', label: 'تعليم' },
  { key: 'business', label: 'أعمال', pro: true },
  { key: 'finance', label: 'مال', pro: true },
  { key: 'pricing', label: 'إعدادات' },
];

export default function Nav({ view, setView, isPro }) {
  return (
    <nav className="fixed bottom-0 inset-x-0 bg-surface border-t border-line overflow-x-auto">
      <div className="flex gap-1 px-3 py-2 min-w-max mx-auto max-w-2xl justify-center">
        {ITEMS.map((item) => (
          <button
            key={item.key}
            onClick={() => setView(item.pro && !isPro ? 'pricing' : item.key)}
            className={
              'px-3 py-2 rounded-full text-xs whitespace-nowrap ' +
              (view === item.key ? 'bg-accent text-accentInk font-bold' : 'text-inkFaint')
            }
          >
            {item.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
