import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

export default function Finance({ userId }) {
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(true);
  const [advice, setAdvice] = useState('');
  const [adviceLoading, setAdviceLoading] = useState(false);

  async function load() {
    const { data } = await supabase
      .from('finance_expenses')
      .select('*')
      .order('created_at', { ascending: true });
    setItems(data || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const total = items.reduce((s, t) => s + Number(t.amount || 0), 0);

  async function addItem(e) {
    e.preventDefault();
    const t = title.trim();
    const a = parseFloat(amount);
    if (!t || Number.isNaN(a)) return;
    setTitle('');
    setAmount('');
    await supabase.from('finance_expenses').insert({ title: t, amount: a, user_id: userId });
    load();
  }

  async function remove(item) {
    await supabase.from('finance_expenses').delete().eq('id', item.id);
    load();
  }

  async function getAdvice() {
    setAdviceLoading(true);
    setAdvice('رفيق كيحلل مصاريفك...');
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            {
              role: 'user',
              content:
                'أنت مستشار مالي ضمن تطبيق "رفيق". هذه المصاريف المسجلة للمستخدم:\n' +
                (items.map((t) => '- ' + t.title + ': ' + t.amount + ' درهم').join('\n') || 'لا مصاريف مسجلة بعد.') +
                '\nالمجموع: ' + total + ' درهم.\n' +
                'أعطه 3 إلى 4 نصائح عملية وموجزة لتحسين إدارة ميزانيته، بالعربية الفصحى المبسطة.',
            },
          ],
        }),
      });
      const data = await res.json();
      setAdvice((data.text || 'تعذر الحصول على نصيحة الآن.') + '\n\nهاذي نصائح عامة، ماشي استشارة مالية مرخصة.');
    } catch (e) {
      setAdvice('تعذر الاتصال بالخدمة الآن.');
    }
    setAdviceLoading(false);
  }

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-sm text-inkFaint">المال</h2>
      <div className="bg-gradient-to-br from-accentDim to-[#123326] border border-[#1F5A46] rounded-2xl p-4">
        <div className="text-xs text-accent mb-1">مجموع المصاريف المسجلة</div>
        <div className="font-cairo font-bold text-xl">{total} درهم</div>
      </div>
      <form onSubmit={addItem} className="flex gap-2">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="وصف المصروف..."
          className="flex-[2] bg-surface border border-line rounded-full px-4 py-3 text-sm outline-none focus:border-accent"
        />
        <input
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="المبلغ"
          inputMode="decimal"
          className="flex-1 bg-surface border border-line rounded-full px-4 py-3 text-sm outline-none focus:border-accent"
        />
        <button className="bg-accent text-accentInk font-bold rounded-full px-5 text-sm">إضافة</button>
      </form>
      <div className="bg-surface border border-line rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-4 text-sm text-inkFaint">جارٍ التحميل...</div>
        ) : items.length === 0 ? (
          <div className="p-4 text-sm text-inkFaint">ما كاين حتى مصروف مسجل</div>
        ) : (
          items.map((item) => (
            <div key={item.id} className="flex items-center gap-3 px-4 py-3 border-b border-line last:border-b-0">
              <div className="flex-1 text-sm">{item.title}</div>
              <div className="text-xs text-inkFaint">{item.amount} درهم</div>
              <button onClick={() => remove(item)} className="text-inkFaint px-1">×</button>
            </div>
          ))
        )}
      </div>
      <button
        onClick={getAdvice}
        disabled={adviceLoading}
        className="bg-accent text-accentInk font-bold rounded-full py-3 text-sm disabled:opacity-50"
      >
        اطلب نصيحة رفيق المالية
      </button>
      {advice && (
        <div className="bg-surface border border-line rounded-2xl p-4 text-xs leading-relaxed whitespace-pre-wrap">
          {advice}
        </div>
      )}
    </div>
  );
}
