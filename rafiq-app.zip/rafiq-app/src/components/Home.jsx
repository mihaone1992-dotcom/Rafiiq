import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

export default function Home({ setView }) {
  const [stats, setStats] = useState({ tasks: 0, goals: 0, finance: 0 });
  const [pendingTasks, setPendingTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [tasks, health, education, business, finance] = await Promise.all([
        supabase.from('tasks').select('*'),
        supabase.from('health_goals').select('*'),
        supabase.from('education_goals').select('*'),
        supabase.from('business_items').select('*'),
        supabase.from('finance_expenses').select('*'),
      ]);
      const t = tasks.data || [];
      const pending = t.filter((x) => !x.done);
      const goalsPending =
        (health.data || []).filter((x) => !x.done).length +
        (education.data || []).filter((x) => !x.done).length +
        (business.data || []).filter((x) => !x.done).length;
      const financeTotal = (finance.data || []).reduce((s, x) => s + Number(x.amount || 0), 0);
      setStats({ tasks: pending.length, goals: goalsPending, finance: financeTotal });
      setPendingTasks(pending.slice(0, 4));
      setLoading(false);
    })();
  }, []);

  return (
    <div className="flex flex-col gap-5">
      <div className="bg-gradient-to-br from-accentDim to-[#123326] border border-[#1F5A46] rounded-2xl p-4">
        <div className="text-xs text-accent mb-1">ملخص اليوم</div>
        <div className="font-cairo font-bold text-base mb-3">
          {loading
            ? 'جارٍ تحميل ملخص اليوم...'
            : stats.tasks === 0 && stats.goals === 0
            ? 'ماشي عندك حتى مهمة أو هدف معلّق دابا.'
            : `عندك ${stats.tasks} مهام باقية و${stats.goals} أهداف نشطة.`}
        </div>
        <div className="flex gap-4">
          <div>
            <div className="font-cairo font-bold text-lg">{stats.tasks}</div>
            <div className="text-[11px] text-inkMuted">مهام باقية</div>
          </div>
          <div>
            <div className="font-cairo font-bold text-lg">{stats.goals}</div>
            <div className="text-[11px] text-inkMuted">أهداف نشطة</div>
          </div>
          <div>
            <div className="font-cairo font-bold text-lg">{stats.finance}</div>
            <div className="text-[11px] text-inkMuted">درهم مصاريف</div>
          </div>
        </div>
      </div>

      <div>
        <div className="flex justify-between text-xs text-inkFaint mb-2">
          <span>مهامك القادمة</span>
          <button onClick={() => setView('tasks')} className="text-accent">عرض الكل</button>
        </div>
        <div className="bg-surface border border-line rounded-2xl overflow-hidden">
          {pendingTasks.length === 0 ? (
            <div className="p-4 text-sm text-inkFaint">ما كاين حتى مهمة معلّقة</div>
          ) : (
            pendingTasks.map((t) => (
              <div key={t.id} className="px-4 py-3 border-b border-line last:border-b-0 text-sm">
                {t.title}
              </div>
            ))
          )}
        </div>
      </div>

      <button
        onClick={() => setView('chat')}
        className="bg-accent text-accentInk font-bold rounded-full py-3 text-sm"
      >
        ابدأ الدردشة مع رفيق
      </button>
    </div>
  );
}
