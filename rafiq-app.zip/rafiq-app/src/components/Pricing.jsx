import { supabase } from '../supabaseClient';

export default function Pricing({ isPro, setIsPro, userId }) {
  async function toggle() {
    const next = !isPro;
    setIsPro(next);
    await supabase.from('profiles').update({ is_pro: next }).eq('id', userId);
  }

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-sm text-inkFaint">النسخة المجانية والاحترافية</h2>
      <div className="bg-surface border border-line rounded-2xl p-5 flex flex-col gap-2">
        <div className="font-cairo font-extrabold">مجانية</div>
        <div className="text-xs text-inkMuted">0 درهم</div>
        <ul className="text-xs text-inkMuted flex flex-col gap-1 mt-2">
          <li>✓ دردشة ذكية مع رفيق</li>
          <li>✓ المهام والتذكيرات</li>
          <li>✓ الصحة، الدين، التعليم</li>
        </ul>
      </div>
      <div className="bg-gradient-to-br from-accentDim to-[#123326] border border-[#1F5A46] rounded-2xl p-5 flex flex-col gap-2">
        <span className="self-start text-[10px] font-extrabold bg-accent text-accentInk rounded-full px-3 py-1">
          الأكثر اكتمالاً
        </span>
        <div className="font-cairo font-extrabold">احترافية</div>
        <div className="text-xs text-inkMuted">اشتراك شهري (يُفعَّل يدويًا بعد التأكد من الدفع)</div>
        <ul className="text-xs text-inkMuted flex flex-col gap-1 mt-2">
          <li>✓ كل مزايا النسخة المجانية</li>
          <li>✓ قسم الأعمال</li>
          <li>✓ قسم المال + المستشار المالي</li>
        </ul>
        <button onClick={toggle} className="mt-3 bg-accent text-accentInk font-bold rounded-full py-3 text-sm">
          {isPro ? 'إلغاء النسخة الاحترافية' : 'تفعيل النسخة الاحترافية'}
        </button>
      </div>
      <button
        onClick={() => supabase.auth.signOut()}
        className="text-inkFaint text-sm text-center py-2"
      >
        تسجيل الخروج
      </button>
    </div>
  );
}
