import { useState, useRef } from 'react';

export default function Chat() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'أهلاً، آش نقدر نعاونك فيه اليوم؟' },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  async function send(e) {
    e.preventDefault();
    const text = input.trim();
    if (!text || sending) return;
    const next = [...messages, { role: 'user', content: text }];
    setMessages(next);
    setInput('');
    setSending(true);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next }),
      });
      const data = await res.json();
      setMessages((m) => [...m, { role: 'assistant', content: data.text || 'ما قدرتش نجاوب دابا.' }]);
    } catch (err) {
      setMessages((m) => [...m, { role: 'assistant', content: 'تعذر الاتصال بالخدمة الآن.' }]);
    }
    setSending(false);
    setTimeout(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, 50);
  }

  return (
    <div className="flex flex-col gap-4 h-[70vh]">
      <h2 className="text-sm text-inkFaint">الدردشة مع رفيق</h2>
      <div ref={scrollRef} className="flex-1 overflow-y-auto flex flex-col gap-3 pr-1">
        {messages.map((m, i) => (
          <div
            key={i}
            className={
              'max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ' +
              (m.role === 'user'
                ? 'self-end bg-accent text-accentInk'
                : 'self-start bg-surface border border-line')
            }
          >
            {m.content}
          </div>
        ))}
      </div>
      <form onSubmit={send} className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="اكتب رسالتك..."
          className="flex-1 bg-surface border border-line rounded-full px-4 py-3 text-sm outline-none focus:border-accent"
        />
        <button disabled={sending} className="bg-accent text-accentInk font-bold rounded-full px-5 text-sm disabled:opacity-50">
          إرسال
        </button>
      </form>
    </div>
  );
}
