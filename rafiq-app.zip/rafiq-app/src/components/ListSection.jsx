import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

export default function ListSection({ table, title, placeholder, userId }) {
  const [items, setItems] = useState([]);
  const [title_, setTitleInput] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    const { data } = await supabase
      .from(table)
      .select('*')
      .order('created_at', { ascending: true });
    setItems(data || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [table]);

  async function addItem(e) {
    e.preventDefault();
    const value = title_.trim();
    if (!value) return;
    setTitleInput('');
    await supabase.from(table).insert({ title: value, done: false, user_id: userId });
    load();
  }

  async function toggleDone(item) {
    await supabase.from(table).update({ done: !item.done }).eq('id', item.id);
    load();
  }

  async function remove(item) {
    await supabase.from(table).delete().eq('id', item.id);
    load();
  }

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-sm text-inkFaint">{title}</h2>
      <form onSubmit={addItem} className="flex gap-2">
        <input
          value={title_}
          onChange={(e) => setTitleInput(e.target.value)}
          placeholder={placeholder}
          className="flex-1 bg-surface border border-line rounded-full px-4 py-3 text-sm outline-none focus:border-accent"
        />
        <button className="bg-accent text-accentInk font-bold rounded-full px-5 text-sm">إضافة</button>
      </form>
      <div className="bg-surface border border-line rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-4 text-sm text-inkFaint">جارٍ التحميل...</div>
        ) : items.length === 0 ? (
          <div className="p-4 text-sm text-inkFaint">ما كاين حتى عنصر دابا</div>
        ) : (
          items.map((item) => (
            <div key={item.id} className="flex items-center gap-3 px-4 py-3 border-b border-line last:border-b-0">
              <button
                onClick={() => toggleDone(item)}
                className="w-7 h-7 rounded-lg bg-surfaceAlt flex items-center justify-center flex-shrink-0"
              >
                {item.done ? (
                  <svg viewBox="0 0 24 24" className="w-4 h-4" stroke="#33D69F" fill="none" strokeWidth="2">
                    <path d="M20 6L9 17l-5-5" />
                  </svg>
                ) : (
                  <svg viewBox="0 0 24 24" className="w-4 h-4" stroke="#8FA6C4" fill="none" strokeWidth="2">
                    <circle cx="12" cy="12" r="8" />
                  </svg>
                )}
              </button>
              <div className={'flex-1 text-sm ' + (item.done ? 'line-through text-inkFaint' : '')}>{item.title}</div>
              <button onClick={() => remove(item)} className="text-inkFaint px-1">×</button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
