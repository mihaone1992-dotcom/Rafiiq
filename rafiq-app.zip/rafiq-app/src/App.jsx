import { useEffect, useState } from 'react';
import { supabase } from './supabaseClient';
import Auth from './components/Auth';
import Nav from './components/Nav';
import Home from './components/Home';
import ListSection from './components/ListSection';
import Finance from './components/Finance';
import Chat from './components/Chat';
import Religion from './components/Religion';
import Pricing from './components/Pricing';

export default function App() {
  const [session, setSession] = useState(undefined); // undefined = loading, null = signed out
  const [view, setView] = useState('home');
  const [isPro, setIsPro] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) return;
    supabase
      .from('profiles')
      .select('is_pro')
      .eq('id', session.user.id)
      .maybeSingle()
      .then(({ data }) => setIsPro(!!data?.is_pro));
  }, [session]);

  if (session === undefined) {
    return <div className="min-h-screen flex items-center justify-center text-inkFaint text-sm">جارٍ التحميل...</div>;
  }

  if (!session) {
    return <Auth />;
  }

  const userId = session.user.id;

  return (
    <div className="min-h-screen pb-24">
      <div className="max-w-lg mx-auto px-4 pt-8">
        {view === 'home' && <Home setView={setView} />}
        {view === 'tasks' && (
          <ListSection table="tasks" title="المهام والتذكيرات" placeholder="أضف مهمة أو تذكيرًا..." userId={userId} />
        )}
        {view === 'health' && (
          <ListSection table="health_goals" title="الصحة" placeholder="هدف صحي جديد..." userId={userId} />
        )}
        {view === 'education' && (
          <ListSection table="education_goals" title="التعليم" placeholder="هدف تعليمي جديد..." userId={userId} />
        )}
        {view === 'business' && isPro && (
          <ListSection table="business_items" title="الأعمال" placeholder="مشروع أو مهمة عمل جديدة..." userId={userId} />
        )}
        {view === 'finance' && isPro && <Finance userId={userId} />}
        {view === 'religion' && <Religion />}
        {view === 'chat' && <Chat />}
        {view === 'pricing' && <Pricing isPro={isPro} setIsPro={setIsPro} userId={userId} />}
      </div>
      <Nav view={view} setView={setView} isPro={isPro} />
    </div>
  );
}
